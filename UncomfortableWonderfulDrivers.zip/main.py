year =int(input("Enter a year:"))
if(year % 4 == 0):
   print("the given year is keep year")
else:
    print("The given year is not a keep year")